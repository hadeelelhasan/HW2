package calcu;

public class MVC {

	public static void main(String[] args) {
		
		View v=new View();
		model m=new model();
		controller cont =new controller(v,m);
                v.setVisible(true);
	}

}
